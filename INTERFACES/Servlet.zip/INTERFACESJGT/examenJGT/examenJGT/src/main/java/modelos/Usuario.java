package modelos;

public class Usuario
{
	private String dni, nombre, apellidos;
	private int idPais;
	private String nombrePais;

	public Usuario(String dni, String nombre, String apellidos)
	{
		this(dni, nombre, apellidos, 1);
	}
	
	public Usuario(String dni, String nombre, String apellidos, int idPais)
	{
		setDni(dni);
		setNombre(nombre);
		setApellidos(apellidos);
		setIdPais(idPais);
	}
	
	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	
	public void setIdPais(int idPais)
	{
		this.idPais = idPais;
	}
	
	public int getIdPais()
	{
		return idPais;
	}
	
	public String getPais()
	{
		return nombrePais;
	}
	
	public void setPais(String nombre)
	{
		nombrePais = nombre;
	}
}
