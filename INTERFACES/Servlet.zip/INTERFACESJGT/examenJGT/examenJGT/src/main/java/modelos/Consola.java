package modelos;

public class Consola
{
	private int idConsola, idEmpresa;
	private String nombre;
	
	
	public Consola(String nombre, int idEmpresa)
	{
		setNombre(nombre);
		setIdEmpresa(idEmpresa);
	}
	
	public Consola (int idConsola, String nombre, int idEmpresa)
	{
		setIdConsola(idConsola);
		setNombre(nombre);
		setIdEmpresa(idEmpresa);
	}
	
	public int getIdConsola() {
		return idConsola;
	}
	public void setIdConsola(int idConsola) {
		this.idConsola = idConsola;
	}
	public int getIdEmpresa() {
		return idEmpresa;
	}
	public void setIdEmpresa(int idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
}
