package modelos;

public class Pais
{
	int idPais;
	String nombre;
	
	public Pais(int idPais, String nombre)
	{
		setIdPais(idPais);
		setNombre(nombre);
	}
	public int getIdPais() {
		return idPais;
	}
	public void setIdPais(int idPais) {
		this.idPais = idPais;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}
