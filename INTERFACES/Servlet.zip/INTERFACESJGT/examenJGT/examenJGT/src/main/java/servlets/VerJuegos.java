package servlets;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basedatos.H2BD;
import modelos.Videojuego;
import repositorios.VideojuegoRepositorio;

public class VerJuegos extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			ArrayList<Videojuego> juegos = selectJuegos();
			req.getSession().setAttribute("juegosList", juegos);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		
		forward(req, resp, "/ListadoVideojuego.jsp");
	}
	
	protected void forward(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(url);
		dispatch.forward(request, response);
	}
	
	private ArrayList<Videojuego> selectJuegos() throws ParseException
	{
		ArrayList<Videojuego> juegos = null;
		H2BD bd = new H2BD();
		bd.initConnect();
		VideojuegoRepositorio er = new VideojuegoRepositorio();
		juegos = er.selectVideojuegos(bd.getConnection());
		bd.close();
		return juegos;
	}
}
