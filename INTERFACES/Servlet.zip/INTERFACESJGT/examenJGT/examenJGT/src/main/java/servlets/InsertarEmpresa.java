package servlets;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basedatos.H2BD;
import modelos.Empresa;
import repositorios.EmpresaRepositorio;

public class InsertarEmpresa extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		System.out.println("Servlet empresa comunicado");
		String nombre = req.getParameter("nombreEmpresa");
		String fechaLeida = req.getParameter("fechaCreacion");
		SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
		Date fechaCreacion = null;
		try
		{
			fechaCreacion = formato.parse(fechaLeida);
		}
		catch (ParseException e)
		{
			System.err.println("Cagada formateando la fecha");
			e.printStackTrace();
		}
		insertarEmpresaBaseDatos(nombre, fechaLeida);
		forward(req, resp, "/index.html");
	}
	
	protected void forward(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(url);
		dispatch.forward(request, response);
	}
	
	private void insertarEmpresaBaseDatos(String nombre, String fecha)
	{
		H2BD bd = new H2BD();
		bd.initConnect();
		EmpresaRepositorio er = new EmpresaRepositorio();
		er.insertarEmpresa(bd.getConnection(), nombre, fecha);
		bd.close();
	}
	
	
}
