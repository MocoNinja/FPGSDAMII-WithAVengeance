package modelos;

import java.util.Date;

public class Videojuego
{
	private int idVideojuego, idConsola;
	private String nombre, edadRecomendada;
	private String fechaPublicacion;
	
	public Videojuego(int idVideojuego, String nombre, String edadRecomendada, int idConsola, String fechaPublicacion)
	{
		setIdVideojuego(idVideojuego);
		setNombre(nombre);
		setEdadRecomendada(edadRecomendada);
		setIdConsola(idConsola);
		setFechaPublicacion(fechaPublicacion);
	}
	
	public int getIdVideojuego() {
		return idVideojuego;
	}
	public void setIdVideojuego(int idVideojuego) {
		this.idVideojuego = idVideojuego;
	}
	public int getIdConsola() {
		return idConsola;
	}
	public void setIdConsola(int idConsola) {
		this.idConsola = idConsola;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEdadRecomendada() {
		return edadRecomendada;
	}
	public void setEdadRecomendada(String edadRecomendada) {
		this.edadRecomendada = edadRecomendada;
	}
	public String getFechaPublicacion() {
		return fechaPublicacion;
	}
	public void setFechaPublicacion(String fechaPublicacion) {
		this.fechaPublicacion = fechaPublicacion;
	}
	
	
}
