package repositorios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import modelos.Empresa;
import modelos.Videojuego;

public class VideojuegoRepositorio
{
	public ArrayList<Videojuego> selectVideojuegos(Connection conn)
	{
		ArrayList<Videojuego> juegos = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Videojuego rescatado = null;
		
		try
		{
			ps = conn.prepareStatement("SELECT * FROM VIDEOJUEGOS");
			rs = ps.executeQuery();
			while (rs != null && rs.next())
			{
				Integer idJuego= rs.getInt("idJuego");
				String nombre = rs.getString("nombre");
				String fechaPublicacion = rs.getString("fechaPublicacion");
				String edadRecomendada = rs.getString("edadRecomendada");
				Integer idConsola= rs.getInt("idConsola");
				rescatado = new Videojuego(idJuego, nombre, edadRecomendada, idConsola, fechaPublicacion);
				juegos.add(rescatado);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error rescatando juegos de la base de datos");
			juegos = null;
		}
		finally
		{
			try {
				rs.close();
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
		return juegos;
	}

	public void insertarJuego(Connection conn, String nombreJuego, String fechaPublicacion, String edadRecomendada,
			int idConsola)
	{
		PreparedStatement ps = null;
		try
		{
			ps = conn.prepareStatement("INSERT INTO VIDEOJUEGOS (nombre, fechaPublicacion, edadRecomendada, idConsola)"
					+ " VALUES (?, ?, ?, ?)");
			ps.setString(1, nombreJuego);
			ps.setString(2, fechaPublicacion);
			ps.setString(3, edadRecomendada);
			ps.setInt(4,  idConsola);
			ps.executeUpdate();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error insertado juegos de la base de datos");
		}
		finally
		{
			try {
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
	}
	
	public void borrarJuego(Connection conn, int idJuego)
	{
		PreparedStatement ps = null;
		try
		{
			ps = conn.prepareStatement("DELETE FROM VIDEOJUEGOS WHERE idJuego = ?");
			ps.setInt(1, idJuego);
			ps.executeUpdate();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error borrando juegos de la base de datos");
		}
		finally
		{
			try {
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
	}
}
