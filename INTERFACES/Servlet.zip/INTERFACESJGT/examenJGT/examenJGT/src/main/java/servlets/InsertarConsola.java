package servlets;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basedatos.H2BD;
import modelos.Consola;
import modelos.Empresa;
import repositorios.ConsolaRepositorio;

public class InsertarConsola extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		System.out.println("Servlet consola comunicado");
		String nombre = req.getParameter("nombreConsola");
		String idEmpresa = req.getParameter("idEmpresa");
		System.out.println(nombre);
		System.err.println("Leidas " + nombre + ", " + idEmpresa);
		insertarConsolaBaseDatos(nombre, Integer.parseInt(idEmpresa));
		forward(req, resp, "/index.html");
	}
	
	protected void forward(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(url);
		dispatch.forward(request, response);
	}
	
	private void insertarConsolaBaseDatos(String nombre, int idEmpresa)
	{
		H2BD bd = new H2BD();
		bd.initConnect();
		ConsolaRepositorio cr = new ConsolaRepositorio();
		cr.insertarConsola(bd.getConnection(), nombre, idEmpresa);
		bd.close();
	} 
	
	
}
