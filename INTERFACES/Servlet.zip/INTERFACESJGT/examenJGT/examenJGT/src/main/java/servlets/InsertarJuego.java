package servlets;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basedatos.H2BD;
import repositorios.VideojuegoRepositorio;

public class InsertarJuego extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		System.out.println("Servlet juego comunicado");
		String nombre = req.getParameter("nombreJuego");
		String edad = req.getParameter("edadRecomendada");
		String fecha = req.getParameter("fechaPublicacion");
		String idConsola = req.getParameter("idConsola");
		insertarVideojuego(nombre, fecha, edad, Integer.parseInt(idConsola));
		
		forward(req, resp, "/index.html");
	}
	
	protected void forward(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(url);
		dispatch.forward(request, response);
	}
	
	private void insertarVideojuego(String nombre, String fecha, String edad, int idConsola)
	{
		H2BD bd = new H2BD();
		bd.initConnect();
		VideojuegoRepositorio vr = new VideojuegoRepositorio();
		vr.insertarJuego(bd.getConnection(), nombre, fecha, edad, idConsola);
		bd.close();
	}
	
}
