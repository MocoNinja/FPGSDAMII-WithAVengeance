package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basedatos.H2BD;
import repositorios.ConsolaRepositorio;
import repositorios.EmpresaRepositorio;
import repositorios.VideojuegoRepositorio;

public class BorrarConfirmation extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String id = req.getParameter("id");
		String modo = req.getParameter("modo");
		req.getSession().setAttribute("modo", modo);
		req.getSession().setAttribute("id", id);
		forward(req, resp, "/borrarConfirm.jsp");
	}
	
	protected void forward(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(url);
		dispatch.forward(request, response);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String modo = req.getParameter("modo");
		String id = req.getParameter("id");
		H2BD bd = new H2BD();
		bd.initConnect();
		switch (modo)
		{
		case "consola":
			ConsolaRepositorio repo = new ConsolaRepositorio();
			repo.borrarConsola(bd.getConnection(), Integer.parseInt(id));
			break;
		case "juego":
			VideojuegoRepositorio r = new VideojuegoRepositorio();
			r.borrarJuego(bd.getConnection(), Integer.parseInt(id));
			break;
		case "empresa":
			EmpresaRepositorio r23 = new EmpresaRepositorio();
			r23.borrarEmpresa(bd.getConnection(), Integer.parseInt(id));
			break;
		}
		bd.close();
		forward(req, resp, "/index.html");
	}
}
