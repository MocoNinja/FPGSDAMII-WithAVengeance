package servlets;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basedatos.H2BD;
import modelos.Empresa;
import repositorios.EmpresaRepositorio;

public class VerEmpresas extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			ArrayList<Empresa> empresas = selectEmpresas();
			req.getSession().setAttribute("empresasList", empresas);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		forward(req, resp, "/ListadoEmpresa.jsp");
	}
	
	protected void forward(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(url);
		dispatch.forward(request, response);
	}
	
	private ArrayList<Empresa> selectEmpresas() throws ParseException
	{
		ArrayList<Empresa> empresas = null;
		H2BD bd = new H2BD();
		bd.initConnect();
		EmpresaRepositorio er = new EmpresaRepositorio();
		empresas = er.selectEmpresas(bd.getConnection());
		bd.close();
		return empresas;
	}
}
