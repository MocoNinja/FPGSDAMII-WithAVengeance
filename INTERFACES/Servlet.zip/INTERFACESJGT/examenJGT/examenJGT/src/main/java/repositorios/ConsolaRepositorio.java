package repositorios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import modelos.Consola;

public class ConsolaRepositorio
{
	public ArrayList<Consola> selectConsolas(Connection conn)
	{
		ArrayList<Consola> consolas = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Consola rescatado = null;
		
		try
		{
			ps = conn.prepareStatement("SELECT * FROM CONSOLAS");
			rs = ps.executeQuery();
			while (rs != null && rs.next())
			{
				Integer idConsola = rs.getInt("idConsola");
				String nombre = rs.getString("nombre");
				Integer idEmpresa = rs.getInt("idEmpresa");
				rescatado = new Consola(idConsola, nombre, idEmpresa);
				consolas.add(rescatado);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error rescatando consolas de la base de datos");
			consolas = null;
		}
		finally
		{
			try {
				rs.close();
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
		return consolas;
	}

	public void insertarConsola(Connection conn, String nombreConsola, int idEmpresa)
	{
		PreparedStatement ps = null;
		try
		{
			ps = conn.prepareStatement("INSERT INTO CONSOLAS (nombre, idEmpresa) VALUES (?, ?)");
			ps.setString(1, nombreConsola);
			ps.setInt(2, idEmpresa);
			ps.executeUpdate();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error insertado consolas de la base de datos");
		}
		finally
		{
			try {
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
	}
	
	public void borrarConsola(Connection conn, int idConsola)
	{
		PreparedStatement ps = null;
		try
		{
			ps = conn.prepareStatement("DELETE FROM CONSOLAS WHERE idConsola = ?");
			ps.setInt(1, idConsola);
			ps.executeUpdate();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error borrando consolas de la base de datos");
		}
		finally
		{
			try {
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
	}
}
