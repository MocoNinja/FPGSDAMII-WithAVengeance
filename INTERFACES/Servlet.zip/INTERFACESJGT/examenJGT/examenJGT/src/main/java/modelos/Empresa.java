package modelos;

public class Empresa 
{
	private String nombre;
	private String fechaCreacion;
	private int idEmpresa;
	
	public Empresa(int idEmpresa, String nombre, String fechaCreacion)
	{
		setIdEmpresa(idEmpresa);
		setNombre(nombre);
		setFechaCreacion(fechaCreacion);
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public int getIdEmpresa() {
		return idEmpresa;
	}
	public void setIdEmpresa(int idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	
	
}
