package basedatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class H2BD
{
	private static final String jdbcUrl = "jdbc:h2:file:./src/main/resources/test;INIT=RUNSCRIPT FROM 'classpath:scripts/create.sql'";
	private Connection conn = null;
	
	public void initConnect()
	{
		try
		{
			Class.forName("org.h2.Driver");
			conn = DriverManager.getConnection(jdbcUrl + ";INIT=RUNSCRIPT FROM 'classpath:scripts/create.sql'", "sa", "");
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.err.println("*** Cagadote conectándose a la base de datos");
			throw new RuntimeException(e);
		}
	}
	
	public void close()
	{
		try
		{
			conn.close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Cagadote cerrando a la base de datos");
			throw new RuntimeException(e);
		}
	}
	
	public Connection getConnection()
	{
		try
		{
			return conn;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.err.println("*** Cagadote devolviendo la conexión");
			throw new RuntimeException(e);
		}
	}
}
