package repositorios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;

import modelos.Empresa;

public class EmpresaRepositorio
{
	public ArrayList<Empresa> selectEmpresas(Connection conn) throws ParseException
	{
		ArrayList<Empresa> empresas = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Empresa rescatado = null;
		
		try
		{
			ps = conn.prepareStatement("SELECT * FROM EMPRESAS");
			rs = ps.executeQuery();
			while (rs != null && rs.next())
			{
				Integer idEmpresa= rs.getInt("idEmpresa");
				String nombre = rs.getString("nombre");
				String fechaCreacion = rs.getString("fechaCreacion");
				System.out.printf("%d, %s, %s%n", idEmpresa, nombre, fechaCreacion);
				rescatado = new Empresa(idEmpresa, nombre, fechaCreacion);
				empresas.add(rescatado);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error rescatando empresas de la base de datos");
			empresas = null;
		}
		finally
		{
			try {
				rs.close();
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
		return empresas;
	}

	public void insertarEmpresa(Connection conn, String nombreEmpresa, String fechaCreacion)
	{
		PreparedStatement ps = null;
		try
		{
			ps = conn.prepareStatement("INSERT INTO EMPRESAS (nombre, fechaCreacion) VALUES (?, ?)");
			ps.setString(1, nombreEmpresa);
			ps.setString(2, fechaCreacion);
			ps.executeUpdate();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error insertado empresas de la base de datos");
		}
		finally
		{
			try {
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
	}
	
	public void borrarEmpresa(Connection conn, int idEmpresa)
	{
		PreparedStatement ps = null;
		try
		{
			ps = conn.prepareStatement("DELETE FROM EMPRESAS WHERE idEmpresa = ?");
			ps.setInt(1, idEmpresa);
			ps.executeUpdate();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			System.err.println("*** Error borrando empresas de la base de datos");
		}
		finally
		{
			try {
				ps.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
				System.err.println("*** Inception error!");
			}
			
		}
	}
}
