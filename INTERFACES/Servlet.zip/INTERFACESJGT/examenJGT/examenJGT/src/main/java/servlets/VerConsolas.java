package servlets;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import basedatos.H2BD;
import modelos.Consola;
import modelos.Videojuego;
import repositorios.ConsolaRepositorio;
import repositorios.VideojuegoRepositorio;

public class VerConsolas extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		try
		{
			ArrayList<Consola> consolas = selectConsolas();
			req.getSession().setAttribute("consolasList", consolas);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		forward(req, resp, "/ListadoConsola.jsp");
	}
	
	private ArrayList<Consola> selectConsolas() throws ParseException
	{
		ArrayList<Consola> consolas = null;
		H2BD bd = new H2BD();
		bd.initConnect();
		ConsolaRepositorio er = new ConsolaRepositorio();
		consolas = er.selectConsolas(bd.getConnection());
		bd.close();
		return consolas;
	}
	
	protected void forward(HttpServletRequest request, HttpServletResponse response, String url)
			throws ServletException, IOException
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(url);
		dispatch.forward(request, response);
	}
}
