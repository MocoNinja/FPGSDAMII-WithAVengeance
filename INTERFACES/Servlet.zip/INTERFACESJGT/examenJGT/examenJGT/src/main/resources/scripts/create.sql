drop table IF EXISTS USER;
drop table IF EXISTS PAIS;

drop table IF EXISTS CONSOLAS;
drop table if EXISTS EMPRESAS;
drop table IF EXISTS VIDEOJUEGOS;


create table IF NOT EXISTS CONSOLAS(
	idConsola int PRIMARY KEY auto_increment,
	nombre varchar(50),
	idEmpresa int
);

create table IF NOT EXISTS EMPRESAS(
	idEmpresa int PRIMARY KEY auto_increment,
	nombre varchar(50),
	fechaCreacion varchar(10)	
);

create table IF NOT EXISTS VIDEOJUEGOS(
	idJuego int PRIMARY KEY auto_increment,
	nombre varchar(50),
	fechaPublicacion date,
	edadRecomendada varchar(50),
	idConsola int
);

insert into empresas (nombre, fechacreacion) values ('Sony', '1212-12-12');
insert into empresas (nombre, fechacreacion) values ('Microsoft', '1212-12-12');
insert into empresas (nombre, fechacreacion) values ('Sega', '1212-12-12');

insert into consolas (nombre, idEmpresa) values ('Play Station 1', 1);
insert into consolas (nombre, idEmpresa) values ('Play Station 2', 1);
insert into consolas (nombre, idEmpresa) values ('Play Station 3', 1);
insert into consolas (nombre, idEmpresa) values ('Xbox', 2);
insert into consolas (nombre, idEmpresa) values ('Sega', 3);
insert into videojuegos (nombre, fechaPublicacion, edadRecomendada, idConsola) values ('Metal Gear Solid', '1212-12-12', '+18', 1);
insert into videojuegos (nombre, fechaPublicacion, edadRecomendada, idConsola) values ('Metal Gear 2', '1212-12-12', '+18', 2);
insert into videojuegos (nombre, fechaPublicacion, edadRecomendada, idConsola) values ('Metal Gear 4', '1212-12-12', '+18', 3);
insert into videojuegos (nombre, fechaPublicacion, edadRecomendada, idConsola) values ('Alguna chufla', '1212-12-12', '+18', 4);
insert into videojuegos (nombre, fechaPublicacion, edadRecomendada, idConsola) values ('Alguno de Sonic', '1212-12-12', '+18', 5);
