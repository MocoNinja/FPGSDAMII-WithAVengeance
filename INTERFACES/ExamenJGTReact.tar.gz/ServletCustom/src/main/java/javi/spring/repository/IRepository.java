package javi.spring.repository;

import java.util.List;

import javi.spring.model.User;

public interface IRepository<T> {
 
	public void insert(T entity);
	
	public void update(T entity);
	
	public void delete(T entity);
	
	public void delete(String id);
	
	public T search(T entity);
	
	public T search(String id);
	
	public List<T> listAll();
	
	public List<T> listAllFCT();
	
	public List<T> listAllNoFCT();

	List<User> listAllSEGUNFCT(String fct);
	
}
