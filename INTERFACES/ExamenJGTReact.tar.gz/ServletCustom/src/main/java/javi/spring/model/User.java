package javi.spring.model;

public class User {

	private String dni;
	private String nombre;
	private String fct;
	
	// A falta de enum, hago esto
	public static final String VA_FCT = "si";
	public static final String NO_VA_FCT = "no";
	
	public User() {
		
	}
	
	public String getFct() {
		return fct;
	}
	
	public void setFct(String va) {
		fct = va;
	}
	
	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "User [dni=" + dni + ", nombre=" + nombre + ", fct=" + fct + "]";
	}

}
