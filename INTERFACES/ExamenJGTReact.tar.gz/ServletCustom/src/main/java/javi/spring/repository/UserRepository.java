package javi.spring.repository;

import java.util.ArrayList;
import java.util.List;
// import org.apache.logging.log4j.LogManager;
// import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import javi.spring.model.User;

@Component
public class UserRepository implements IRepository<User> {
	// private static Logger log = LogManager.getLogger(UserRepository.class);

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	NamedParameterJdbcTemplate namedJdbcTemplate;

	@Override
	public void insert(User user) {
		// log.debug("el log funciona");
		String sql = "INSERT INTO USER (dni,nombre,fct)" + "VALUES ( :dni, :nombre, :fct)";
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("dni", user.getDni());
		params.addValue("nombre", user.getNombre());
		params.addValue("fct", user.getFct());
		namedJdbcTemplate.update(sql, params);
	}

	@Override
	public void update(User user) {
		String sql = "UPDATE user SET " + "nombre = ?, fct = ? WHERE dni = ?";
		jdbcTemplate.update(sql, user.getNombre(), user.getFct(), user.getDni());
	}
	
	public void update(String dni, String name, String fct) {
		String sql = "UPDATE user SET " + "nombre = ?, fct = ? WHERE dni = ?";
		jdbcTemplate.update(sql, name, fct, dni);
	}

	@Override
	public void delete(User user) {
		delete(user.getDni());

	}
	
	@Override
	public void delete(String id) {
		String sql = "DELETE FROM USER WHERE dni=?";
		// log.debug(sql);
		System.out.println(sql);
		jdbcTemplate.update(sql, id);
	}

	@Override
	public User search(User user) {
		String sql = "SELECT * FROM USER WHERE dni = ?";
		// log.debug("ejecutando la consulta: " + sql);
		User person = null;
		try {
			person = (User) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(User.class), user.getDni());
		} catch (EmptyResultDataAccessException e) {
			// log.error("error", e);
		}
		return person;
	}

	@Override
	public List<User> listAll() {
		String sql = "SELECT * FROM USER";
		List<User> users = jdbcTemplate.query(sql, new BeanPropertyRowMapper(User.class));
		return users;
	}

	@Override
	public User search(String id) {
		String sql = "SELECT * FROM USER WHERE dni = ?";
		// log.debug("ejecutando la consulta: " + sql);
		User person = null;
		try {
			person = (User) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(User.class), id);
		} catch (EmptyResultDataAccessException e) {
			// log.error("error", e);
		}
		return person;
	}

	@Override
	public List<User> listAllFCT() {
		String sql = "SELECT * FROM USER WHERE fct = 'si'";
		// log.debug("ejecutando la consulta: " + sql);
		List<User> person = new ArrayList<>();
		try {
			person = (List<User>) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(User.class));
		} catch (EmptyResultDataAccessException e) {
			// log.error("error", e);
		}
		if (person.size() == 0) person = null; // Apaño a falta de tiempo para hacer algo más sofisticado
		return person;
	}

	@Override
	public List<User> listAllNoFCT() {
		String sql = "SELECT * FROM USER WHERE fct = 'no'";
		// log.debug("ejecutando la consulta: " + sql);
		List<User> person = new ArrayList<>();
		try {
			person = (List<User>) jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper(User.class));
		} catch (EmptyResultDataAccessException e) {
			// log.error("error", e);
		}
		if (person.size() == 0) person = null; // Apaño a falta de tiempo para hacer algo más sofisticado
		return person;
	}
	
	@Override
	public List<User> listAllSEGUNFCT(String fct) {
		String sql = "SELECT * FROM USER WHERE fct = ?";
		// log.debug("ejecutando la consulta: " + sql);
		List<User> person = new ArrayList<>();
		try {
			person = (List<User>) jdbcTemplate.query(sql, new BeanPropertyRowMapper(User.class), fct);
		} catch (EmptyResultDataAccessException e) {
			// log.error("error", e);
		}
		if (person.size() == 0) person = null; // Apaño a falta de tiempo para hacer algo más sofisticado
		return person;
	}
}
