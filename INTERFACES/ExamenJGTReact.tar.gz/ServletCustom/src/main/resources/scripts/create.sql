create table IF NOT EXISTS USER(
	dni varchar(25) PRIMARY KEY,
	nombre varchar(25),
	fct varchar(25)
);