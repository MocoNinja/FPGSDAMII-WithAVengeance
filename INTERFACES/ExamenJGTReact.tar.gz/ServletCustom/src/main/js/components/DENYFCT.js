import React from "react";

export default class DENYFCT extends React.Component {

	constructor(props) {
		super(props)
		this.state = { id: props.id }
	}

	delete(event) {
		fetch('/api/v1/user/DENYFCT/?id=' + this.state.id)
	}

	render() {
		return (
			<button onClick={this.delete.bind(this)}>
				Adiós sus prácticas
			</button>
		)
	}
}