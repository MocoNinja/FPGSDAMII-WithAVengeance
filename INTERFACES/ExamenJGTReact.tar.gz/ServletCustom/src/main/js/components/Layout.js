import React from "react"
import { addUser } from "../actions/userActions"
import AddUserForm from "./AddUserForm"
import UserList from "./UserList"
import UserListNOFCT from "./UserListNOFCT"

export default class Layout extends React.Component {

  render() {
   
    return (
      <div class="text-center">
        <AddUserForm />
        <h1>NO RIP</h1>
        <UserList />
        <h1>RIP</h1>
        <UserListNOFCT />
      </div>
    )
  }
}
