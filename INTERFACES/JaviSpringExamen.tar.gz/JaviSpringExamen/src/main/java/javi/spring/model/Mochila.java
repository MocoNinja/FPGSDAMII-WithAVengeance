package javi.spring.model;

import java.util.ArrayList;
import java.util.List;

public class Mochila {
	List<Objeto> objetosEnMochila = new ArrayList<>();
	
	public List<Objeto> getObjetoEnMochila() {
		return objetosEnMochila;
	}
}
