package javi.spring.model;

public class Soldado {
	
	private String nombre;
	private Arma armaPrimaria, armaSecundaria;
	private Mochila mochila;
	
	
	public Arma getArmaPrimaria() {
		return armaPrimaria;
	}

	public void setArmaPrimaria(Arma armaPrimaria) {
		this.armaPrimaria = armaPrimaria;
	}

	public Arma getArmaSecundaria() {
		return armaSecundaria;
	}

	public void setArmaSecundaria(Arma armaSecundaria) {
		this.armaSecundaria = armaSecundaria;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Mochila getMochila() {
		return mochila;
	}

	public void setMochila(Mochila mochila) {
		this.mochila = mochila;
	}
	
}
