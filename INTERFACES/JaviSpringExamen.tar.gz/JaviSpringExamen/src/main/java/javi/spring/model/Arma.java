package javi.spring.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Arma extends Objeto {
	List<Objeto> objetosDelArma = new ArrayList<>();
	private static Logger log = LogManager.getLogger(Arma.class);
	
	public List<Objeto> getObjetosDelArma() {
		return objetosDelArma;
	}
	
	public void addComplemento (Objeto objeto) throws Exception {
		// if (!objeto.tipo.equals(Objeto.Tipo.ADDON)) { // No me da tiempo implementarlo asi ni de coña
		if (!objeto.tipo.equals("addon")) {
			log.debug("Error, se está intentando añadir a un arma algo que no es un addon");
			throw new Exception("NOHASAÑADIDOUNADDONEXCEPTION");
		} else {
			objetosDelArma.add(objeto);
		}
	}
	
	public void clean() {
		objetosDelArma = new ArrayList<>();
	}
}
