package javi.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import javi.spring.model.Arma;
import javi.spring.model.Objeto;
import javi.spring.model.Soldado;
import javi.spring.service.Mochila;

@Controller
public class IndexController {
	private static Logger log = LogManager.getLogger(IndexController.class);
	private Soldado user;
	private List<Arma> equipadas = new ArrayList<>();
	private List<Objeto> inventario = new ArrayList<>();
	private Arma seleccionada;
	
	@Autowired
	Mochila mochila; // ojo que es service, que con las prisas no he pensado bien los nombres
	
	
	@GetMapping("/")
	public ModelAndView index() {
		log.log(Level.ALL, "Starting the application");
		user = new Soldado();
		ModelAndView modelAndView = new ModelAndView("index", "command", user);
		modelAndView.addObject("soldado", this.user);
		return modelAndView;
	}
	
	@PostMapping("/User/Add")
	public ModelAndView addUser(Soldado user) {
		log.debug("Añadiendo nombre del soldado");
		ModelAndView modelAndView = new ModelAndView("index", "command", user);
		modelAndView.addObject("soldado", this.user);
		return modelAndView;
	}
	
	@PostMapping("/Item/Add")
	public ModelAndView addItem(Objeto objeto) throws Exception {
		log.debug("Añadiendo objeto");
		if (objeto.getTipo().equals("ARMA")) manejarArma(objeto);
		else if (objeto.getTipo().equals("ADDON")) manejarAddon(objeto);
		else manejarItem(objeto);
		inventario.add(objeto); // Siempre se mete al inventario sea lo que sea
		return manejarInventario(); // Meter para mostrar
	}
	
	private ModelAndView manejarInventario() {
		log.debug("Mostrando el inventario");
		ModelAndView modelAndView = new ModelAndView("index", "command", user);
		modelAndView.addObject("armas", equipadas);
		modelAndView.addObject("inventario", inventario);
		return modelAndView;
	}
	
	private void manejarItem(Objeto objeto) {
		mochila.addItem(objeto);
	}

	private void manejarAddon(Objeto objeto) throws Exception {
		// Van al arma, no a la mochila
		if (seleccionada != null) {
			seleccionada.addComplemento(objeto);
		} else {
			log.debug("Intentando añadir complementos sin haber seleccionado un arma");
		}
	}

	private void manejarArma(Objeto item) {
		// No va a la mochila, va al inventario
		Arma arma = (Arma) item;
		if (seleccionada == null) {
			seleccionada = arma;
		} else {
			seleccionada.clean(); // Al cambiar de arma, se quitan los mods
		}
		if (this.user.getArmaSecundaria() != null) {
			if (this.user.getArmaPrimaria() != null ) {
				log.debug("Desequipando arma primaria previa");
			} 
			this.user.setArmaPrimaria(arma);
		} else {
			this.user.setArmaSecundaria(arma);
		}
	}
	
	@PostMapping("/Weapon/Change")
	private String cambiarArma(Arma arma) {
		
		seleccionada = arma;
		return "index";
	}
}
