package javi.spring.service;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import javi.spring.model.Objeto;

@Service
@Profile("Tipo2")
public class MochilaTipo2 implements Mochila {

	private final int pesoMaximo = 100;
	private final ArrayList<Objeto> objetos = new ArrayList<>();
	private static Logger log = LogManager.getLogger(MochilaTipo2.class);
	
	@Override
	public boolean isFull() {
		int pesoContenido = 0;
		
		for (Objeto objeto : objetos) {
			pesoContenido += objeto.getPeso();
		}
		if (pesoContenido > pesoMaximo) {
			log.debug("Peso Excesivo");
		}
		return pesoContenido >= pesoMaximo;
	}

	@Override
	public void addItem(Objeto item) {
		objetos.add(item);
	}

	@Override
	public int spaceAvalaible() {
		int pesoContenido = 0;
		
		for (Objeto objeto : objetos) {
			pesoContenido += objeto.getPeso();
		}
		
		if (pesoContenido > pesoMaximo) {
			log.debug("Peso Excesivo : No queda nada");
		}
		
		int diferencia = pesoMaximo- pesoContenido;
		return (diferencia > 0) ? diferencia : 0;
	}

}
