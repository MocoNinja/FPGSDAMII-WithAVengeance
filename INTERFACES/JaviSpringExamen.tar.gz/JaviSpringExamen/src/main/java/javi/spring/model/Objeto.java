package javi.spring.model;


public class Objeto {
	String nombre, tipo;
	int peso;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public int getPeso() {
		return peso;
	}
	public void setPeso(int peso) {
		this.peso = peso;
	}
	
	/*
	 * Complicado de implementar asi
	public enum Tipo {
		ARMA,
		ADDON,
		OTRO
	};
	*/
}
