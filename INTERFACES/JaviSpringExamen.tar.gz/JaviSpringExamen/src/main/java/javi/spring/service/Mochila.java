package javi.spring.service;

import org.springframework.stereotype.Service;

import javi.spring.model.Objeto;

@Service
public interface Mochila {

	boolean isFull();

	void addItem(Objeto item);

	int spaceAvalaible();
}
