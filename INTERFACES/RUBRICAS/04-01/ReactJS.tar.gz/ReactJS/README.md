# Install the dependencies
npm install

# Run your app
npm start
