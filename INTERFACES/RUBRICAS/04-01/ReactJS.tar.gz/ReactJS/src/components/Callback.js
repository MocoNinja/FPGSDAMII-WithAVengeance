import { Component } from 'react';


class Callback extends Component {

  componentDidMount() {
    window.location.href = "/";
  }

  render() {
    return null;
  }
}

export default Callback;
