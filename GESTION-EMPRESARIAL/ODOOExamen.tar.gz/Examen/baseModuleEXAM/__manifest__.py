# -*- coding: utf-8 -*-
{
    'name': "baseModule",

    'summary': """
        modulo base EXAM VERSION""",

    'description': """
        Modulo base para examenes
    """,

    'author': "Gorka Sanz",
    'website': "https://zaragoza.salesianos.edu/",
    'category': 'examen',
    'version': '1.0',
    'depends': ['base'],
    'data': [
        'views/base.xml',
    ],
}