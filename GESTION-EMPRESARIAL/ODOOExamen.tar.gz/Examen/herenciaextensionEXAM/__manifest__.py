# -*- coding: utf-8 -*-
{
    'name': "herenciaextension",

    'summary': """
        modulo herenciaextension DEL EXAMEN""",

    'description': """
        Modulo que muestra la herencia mediante extension para examenes
    """,

    'author': "Javier González Tello",
    'website': "https://zaragoza.salesianos.edu/",
    'category': 'examen',
    'version': '1.0',
    'depends': ['base','baseModule'],
    'data': [
        'views/base.xml',
    ],
}