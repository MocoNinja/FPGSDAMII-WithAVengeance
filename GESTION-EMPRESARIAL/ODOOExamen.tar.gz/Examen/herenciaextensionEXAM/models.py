# -*- coding: utf-8 -*-

from datetime import datetime
from odoo import models, fields, api, exceptions


class vehiculo(models.Model):
    _name = 'herenciaextension.vehiculo'
    marca = fields.Char()
    color = fields.Selection(
        selection=[('blanco', 'Blanco'), ('gris', 'Gris'), ('negro', 'Negro')])
    asientos = fields.Integer()
    conductores = fields.Many2many('base.entidad', string="Conductores")
    viajesrealizados_ids = fields.One2many(
        'herenciaextension.viaje', 'cocheusado_id', string="Sus viajes")
    seguro_id = fields.Many2one(
        'herenciaextension.seguro', ondelete='set null', string="Seguro", index=True)
    name = fields.Char(compute='_getDisplay')
    @api.multi
    def _getDisplay(self):
        for record in self:
            record.name = record.marca


class provincia(models.Model):
    _name = 'herenciaextension.provincia'
    nombre = fields.Char()
    provinciasZero_ids = fields.One2many(
        'herenciaextension.viaje', 'provinciaZero_id', string="Sus provincias Inicio")
    provinciasFin_ids = fields.One2many(
        'herenciaextension.viaje', 'provinciaFin_id', string="Sus provincias Destino")

    name = fields.Char(compute='_getDisplay')
    @api.multi
    def _getDisplay(self):
        for record in self:
            record.name = record.nombre


class viaje(models.Model):
    _name = 'herenciaextension.viaje'
    horas = fields.Integer()
    cocheusado_id = fields.Many2one(
        'herenciaextension.vehiculo', ondelete='set null', string="Coche Usado", index=True)
    provinciaZero_id = fields.Many2one(
        'herenciaextension.provincia', ondelete='set null', string="Provincia Inicio", index=True)
    provinciaFin_id = fields.Many2one(
        'herenciaextension.provincia', ondelete='set null', string="Provincia Destino", index=True)
    largo = fields.Boolean(compute='_esviajelargo', default=False)
    fecha = fields.Date()
    # fechainicio = fields.Date(compute='_getNow')
    fechainicio = fields.Date(default=lambda self: fields.datetime.now())
    
    """
    @api.multi
    def _getNow(self):
        for record in self:
            record.fechainicio = fields.Datetime(datetime.now())
    """
    @api.onchange('horas')
    def _esviajelargo(self):
        for record in self:
            record.largo = record.horas > 2


class conductor(models.Model):
    _inherit = 'base.entidad'
    dni = fields.Char()
    vehiculos = fields.Many2many(
        'herenciaextension.vehiculo', string="Vehiculos")


class seguro(models.Model):
    _inherit = 'base.empresa'
    _name = 'herenciaextension.seguro'
    fecha = fields.Date()
    nombre = fields.Char()
    cochesasegurados_ids = fields.One2many(
        'herenciaextension.vehiculo', 'seguro_id', string="Sus coches asegurados")
    fechainicio = fields.Date(default=lambda self: fields.datetime.now())
    """
    ESTO LO DEJO COMENTADO POR LA CAPTURA
    name = fields.Char(compute='_getDisplay')
    @api.multi
    def _getDisplay(self):
        for record in self:
            record.name = record.nombre

    """

    """
    @api.multi
    def _getNow(self):
        for record in self:
            record.fechainicio = fields.Datetime(datetime.now())
    """
